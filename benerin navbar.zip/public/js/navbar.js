// public/js/navbar.js
document.addEventListener("DOMContentLoaded", () => {
  const navbar = document.getElementById("mainNavbar");
  if (!navbar) return;

  // halaman yang punya hero di atas (home & mitra)
  const hasHeroTop = !!document.querySelector(".hero, .mitra-hero");

  const setTransparent = () => {
    navbar.classList.add("navbar-transparent");
    navbar.classList.remove("navbar-scrolled");
  };

  const setScrolled = () => {
    navbar.classList.add("navbar-scrolled");
    navbar.classList.remove("navbar-transparent");
  };

  const updateNavbar = () => {
    if (!hasHeroTop) {
      // halaman biasa → selalu putih
      setScrolled();
      return;
    }

    // halaman hero → transparan di top
    if (window.scrollY > 20) setScrolled();
    else setTransparent();
  };

  // INIT (INI YANG PENTING)
  updateNavbar();

  window.addEventListener("scroll", updateNavbar, { passive: true });

  // saat navbar collapse dibuka (mobile)
  const collapse = document.getElementById("mainNavbarNav");
  if (collapse) {
    collapse.addEventListener("show.bs.collapse", setScrolled);
    collapse.addEventListener("hidden.bs.collapse", updateNavbar);
  }
});
